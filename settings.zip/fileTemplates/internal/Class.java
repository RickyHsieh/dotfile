#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * ${NAME}. ${YEAR}/${MONTH}/${DAY} ${HOUR}:${MINUTE}
 * Description: ${DESCRIPTION}
 * Author: ${USER}
 * @version 1.0.0
 */
public class ${NAME} {
}
